/* WhatsApp: cada botão leva a mensagem pronta do assunto da página.
   Preencha WA_NUMERO só com números (55 + DDD + número), ex.: "5527999999999".
   Enquanto estiver vazio, os botões usam o link curto do WhatsApp Business. */
(function () {
  var WA_NUMERO = "5527992917892";
  var LINK_CURTO = "https://wa.me/message/HDGZGFYURGO4L1";

  document.querySelectorAll("[data-wa]").forEach(function (a) {
    var msg = a.getAttribute("data-wa");
    a.href = WA_NUMERO
      ? "https://wa.me/" + WA_NUMERO + "?text=" + encodeURIComponent(msg)
      : LINK_CURTO;
    a.target = "_blank";
    a.rel = "noopener";
    a.addEventListener("click", function () {
      if (typeof window.gtag === "function") {
        window.gtag("event", "conversion", { send_to: "AW-18538815273/GOVJCMW4irQdEKm-_4dF" });
        window.gtag("event", "contato_whatsapp", { pagina: location.pathname });
      }
    });
  });

  var ano = document.getElementById("ano");
  if (ano) ano.textContent = new Date().getFullYear();
})();
